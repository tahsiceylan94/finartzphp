<?php

	function getAllLanguages($baglanti,$selectLang = ""){
		$sorgu = $baglanti->query("SELECT * FROM languages");

		while ($cikti = $sorgu->fetch_array()) {
			echo '<option value="'.$cikti["iso_639-1"].'"';
			
			if($selectLang == $cikti["iso_639-1"]){echo ' selected';}
			
			echo '>'.$cikti["name"].'</option>';
		}
		
		return $lang;
	}
	
	function getLastHistory($baglanti){
		
		$result = $baglanti->query("SELECT * FROM history order by id desc limit 0,20");

		while ($row = $result->fetch_assoc()) {
			
			$history .= '<li class="list-group-item d-flex justify-content-between lh-sm">
					<div>
					  <h6 class="my-0">'.$row['fromtext'].' ('.$row['fromtranslate'].')</h6>
					  <small class="text-muted">'.$row['totext'].' ('.$row['translate'].')</small>
					</div>
					<span class="text-muted"><a href="/index.php?deletehistory='.$row['id'].'" title="delete">delete</a></span>
				  </li>';
		}
		
		return $history;
	}
	
	function getHistoryCount($baglanti){
		
		$result = $baglanti->query("SELECT COUNT(*) FROM history");

		$row = $result->fetch_assoc();
		
		return $row['COUNT(*)'];
	}
	
	
?>