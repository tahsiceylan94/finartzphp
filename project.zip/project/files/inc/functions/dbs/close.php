<?php

	$baglanti->close();

?>