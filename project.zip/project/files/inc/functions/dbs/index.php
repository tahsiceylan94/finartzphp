<?php error_reporting(0);

$baglanti = new mysqli("localhost", "root", "", "ttranslate");

if ($baglanti->connect_errno > 0) {
    die("<b>Bağlantı Hatası:</b> " . $baglanti->connect_error);
}

$baglanti->set_charset("utf8");

/*Get Language*/
$fromlang	= $_GET['fromlang'];
$tolang		= $_GET['tolang'];
$ttext		= $_GET['ttext'];
$tsearch	= $_GET['ttext'];

include_once("inc/functions/all.php");


$search  = array(' ');
$replace = array('%20');
$ttext =  str_replace($search, $replace, $ttext);

$ttext = preg_replace( "/(\r|\n)/", "", $ttext );

if(isset($_GET) && $_GET['ttext'] != ""){
	
	//set map api url
	$url = "https://translation.googleapis.com/language/translate/v2?key=AIzaSyDLy_u8USuQL4n2XPllqb3f4-zLDFM_bL4&target=".$tolang."&q=".$ttext;

	//call api
	$json = file_get_contents($url);
	$json = json_decode($json);

	$translateText	= $json->data->translations[0]->translatedText;
	$detectedLang	= $json->data->translations[0]->detectedSourceLanguage;
	
	//sessions
	$_SESSION['tsearch']		= $tsearch;
	$_SESSION['tolang']			= $tolang;
	$_SESSION['detectedLang']	= $detectedLang;
	$_SESSION['translateText']	= $translateText;
	$_SESSION['butonhide']		= 'ok';
	$_SESSION['show']			= 0;
	
	//recording
	$sql = "INSERT INTO history (fromtext, totext, fromtranslate, translate) VALUES ('$detectedLang', '$tolang', '$tsearch', '$translateText')";
	$baglanti->query($sql);

	header('Location: /');
		
}

if(isset($_GET) && $_GET['deletehistory'] != ""){
	//recording
	$sql = "DELETE FROM history where id=".$_GET['deletehistory'];
	if($baglanti->query($sql)){
		header('Location: /?del=ok');
	}	
}

?>