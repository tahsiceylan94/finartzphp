<?php session_start(); include_once('inc/functions/dbs/index.php'); ?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="generator" content="Tahsin Berk Ceylan">
    <title>Translate</title>
    

    <!-- Bootstrap core CSS -->
	<link href="inc/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" >
	
	
	<link href="inc/assets/common/css/style.css" rel="stylesheet" >
	
  </head>
  <body class="bg-light">
    
<div class="container">
<?php
	if(isset($_GET) && $_GET['del'] == "ok"){
	//recording
	echo '<div class="alert alert-success mt-4" role="alert">Kayıt başarıyla silindi</div>';
}
?>
  <main>
    <div class="py-5 text-center">
      <img class="d-block mx-auto mb-4" src="inc/assets/common/img/logo.png" alt="" width="72">
      <h2>tTranslate</h2>
      <p class="lead">just translate it, you'll find everything.</p>
    </div>
<form method="get" action="" name="translateform" id="translateform">
    <div class="row g-5">
	
	<div class="col-md-12 col-lg-6">
        <h3 class="mb-3">
			<label for="translatefrom">Translate From:</label>
		</h3>
        
          <div class="row g-3">
		  
			<div class="col-12">
				<select class="form-select commonselect" name="fromlang" aria-label="Default select example">
				  <option value="detect" selected>Detect Language</option>
				  <?php $lang = ""; getAllLanguages($baglanti,$_SESSION['detectedLang']); ?>
				</select>
			</div>
                       
            <div class="col-12">
			   <textarea class="form-control" id="translatefrom" name="ttext" placeholder="Text" style="height: 100px" required><?php if($_SESSION['tsearch'] != ""){echo $_SESSION['tsearch'];} ?></textarea>
            </div>
            
          </div>

          <hr class="my-4">

          <input class="sendtranslate w-100 btn btn-primary btn-lg <?php if($_SESSION['butonhide'] == 'ok'){echo 'disabled';} ?>" type="submit" value="Translate it!">
        
      </div>
      <div class="col-md-12 col-lg-6">
		<h3 class="mb-3">
			<label for="translatefrom">Translate To:</label>
		</h3>
		  <form class="needs-validation" novalidate>
			  <div class="row g-3">
			  
				<div class="col-12">
					<select class="form-select commonselect" name="tolang"  aria-label="Default select example">
					  <?php $lang = ""; getAllLanguages($baglanti,$_SESSION['tolang']); ?>
					</select>
				</div>
						   
				<div class="col-12">
				   <div class="form-control translateText">
						<?php echo $_SESSION['translateText']; ?>
				   </div>
				</div>
				
			  </div>

		  <hr class="my-4">

		  <h4 class="d-flex justify-content-between align-items-center mb-3">
          <span class="text-primary">Search History (Last 20):</span>
          <span class="badge bg-primary rounded-pill">All: <?php echo getHistoryCount($baglanti); ?></span>
        </h4>
        <ul class="list-group mb-3">
          <?php echo getLastHistory($baglanti); ?>
        </ul>
		</form>
        
      </div>
      
    </div>
	</form>
  </main>

  <footer class="my-5 pt-5 text-muted text-center text-small">
    <p class="mb-1">&copy; 2021 tTranslate</p>
  </footer>
</div>


    <script src="inc/assets/bootstrap/js/bootstrap.bundle.min.js" ></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	  <script>
	  $(document).ready(function(){
		<?php if(isset($_GET) && $_GET['del'] == "ok"){ ?>
			setTimeout(function(){ window.location.href = "/"; }, 3000);
		<?php } ?>
		
		<?php if($_SESSION['tsearch'] != ""){ ?>
			$( ".sendtranslate" ).addClass( "disabled" );
			setTimeout(function(){ $( ".sendtranslate" ).removeClass( "disabled" ); }, 10000);
		<?php } ?>
		
		$('.commonselect').on('change', function() {
		  $( ".sendtranslate" ).removeClass( "disabled" )
		});
	  });
	  </script>
  </body>
</html>
<?php include('inc/functions/dbs/close.php'); ?>

<?php
	$_SESSION['show']++;
	if($_SESSION['show'] > 1){
		$_SESSION['tsearch']		= "";
		$_SESSION['tolang']			= "";
		$_SESSION['detectedLang']	= "";
		$_SESSION['translateText']	= "";
		$_SESSION['show']	= 0;
		$_SESSION['butonhide']	= "";
	}	
	
?>