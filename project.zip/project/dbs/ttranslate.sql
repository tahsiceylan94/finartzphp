-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 13 Tem 2021, 16:04:00
-- Sunucu sürümü: 10.4.17-MariaDB
-- PHP Sürümü: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `ttranslate`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `history`
--

CREATE TABLE `history` (
  `id` int(11) NOT NULL,
  `fromtext` text DEFAULT NULL,
  `totext` text DEFAULT NULL,
  `fromtranslate` text DEFAULT NULL,
  `translate` text DEFAULT NULL,
  `date` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `history`
--

INSERT INTO `history` (`id`, `fromtext`, `totext`, `fromtranslate`, `translate`, `date`) VALUES
(3, 'en', 'tr', 'my name is tahsin', 'benim adım tahsin', '2021-07-13 15:45:42'),
(4, 'tr', 'en', 'bir gözlüğe sahibim', 'i have a glasses', '2021-07-13 15:46:11'),
(5, 'tr', 'en', 'renk', 'color', '2021-07-13 15:46:21'),
(6, 'tr', 'it', 'yeni bilgisayar', 'nuovo computer', '2021-07-13 15:46:35'),
(7, 'tr', 'es', 'kahve makinası çok iyi', 'muy buena maquina de cafe', '2021-07-13 15:46:50'),
(8, 'en', 'es', 'my favorite color is black', 'mi color favorito es el negro', '2021-07-13 15:47:26'),
(9, 'en', 'es', 'this is translate', 'esto es traducido', '2021-07-13 15:47:42'),
(11, 'en', 'de', 'this translate will be german', 'diese übersetzung wird deutsch sein', '2021-07-13 15:49:07'),
(12, 'tr', 'bg', 'çevirilecek içerik bulgarca olacaktır', 'Съдържанието, което ще бъде преведено, ще бъде на български език', '2021-07-13 15:49:26'),
(13, 'tr', 'ar', 'Arapça kullanımı zor bir dildir', 'اللغة العربية لغة صعبة الاستخدام', '2021-07-13 15:50:03'),
(14, 'tr', 'be', 'Kulaklık', 'Навушнікі', '2021-07-13 15:50:16'),
(15, 'tr', 'in', 'Kahve bardağı çok büyük', 'Cangkir kopi terlalu besar', '2021-07-13 15:50:38'),
(17, 'en', 'az', 'my computer battery is low', 'kompüterimin batareyası azdır', '2021-07-13 15:51:38'),
(18, 'az', 'en', 'mona lisa rəsm əsli', 'mona lisa painting original', '2021-07-13 15:52:28'),
(19, 'en', 'tr', 'Covid 19 badly effected us', 'Covid 19 bizi kötü etkiledi', '2021-07-13 15:53:42'),
(20, 'en', 'tr', 'this is search history', 'bu arama geçmişi', '2021-07-13 15:53:59'),
(21, 'en', 'tr', 'start at top negotiate down', 'yukarıdan başla aşağı pazarlık', '2021-07-13 15:54:46'),
(22, 'en', 'tr', 'little less conversation and little more action please', 'biraz daha az konuşma ve biraz daha fazla hareket lütfen', '2021-07-13 15:55:20'),
(23, 'tr', 'am', 'telefonu şarja taktım', 'ስልኩን ቻርጅ አድርጌያለሁ', '2021-07-13 15:55:38'),
(24, 'tr', 'zh', 'klima çalışmıyor', '空调不工作', '2021-07-13 15:56:02'),
(29, 'tr', 'cy', 'usb çoklayıcı', 'amlblecsydd usb', '2021-07-13 15:57:58'),
(30, 'tr', 'cy', 'usb çoklayıcı', 'amlblecsydd usb', '2021-07-13 16:01:33'),
(31, 'tr', 'cy', 'usb çoklayıcı', 'amlblecsydd usb', '2021-07-13 16:01:53'),
(32, 'tr', 'cy', 'usb çoklayıcı', 'amlblecsydd usb', '2021-07-13 16:02:17'),
(33, 'tr', 'cy', 'usb çoklayıcı', 'amlblecsydd usb', '2021-07-13 16:04:09'),
(34, 'tr', 'cy', 'usb çoklayıcı', 'amlblecsydd usb', '2021-07-13 16:04:25'),
(37, 'tr', 'cy', 'usb çoklayıcı', 'amlblecsydd usb', '2021-07-13 16:06:29'),
(38, 'tr', 'cy', 'usb çoklayıcı', 'amlblecsydd usb', '2021-07-13 16:06:33'),
(39, 'tr', 'cy', 'usb çoklayıcı', 'amlblecsydd usb', '2021-07-13 16:06:46'),
(41, 'tr', 'en', 'bardak', 'glass', '2021-07-13 16:15:29'),
(42, 'tr', 'en', 'şeker', 'candy', '2021-07-13 16:19:30'),
(43, 'tr', 'en', 'klavye', 'keyboard', '2021-07-13 16:40:20'),
(44, 'tr', 'en', 'klavye', 'keyboard', '2021-07-13 16:40:24'),
(45, 'tr', 'en', 'paylaş', 'share', '2021-07-13 16:42:04'),
(46, 'tr', 'en', 'yeni yazı', 'new post', '2021-07-13 16:48:46'),
(47, 'tr', 'en', 'kitap', 'book', '2021-07-13 16:50:16'),
(48, 'tr', 'en', 'telefon', 'telephone', '2021-07-13 16:55:18'),
(49, 'tr', 'en', 'telefon', 'telephone', '2021-07-13 16:55:34'),
(50, 'tr', 'en', 'gözlük', 'glasses', '2021-07-13 17:02:12'),
(51, 'tr', 'en', 'kulaklık', 'headphone', '2021-07-13 17:03:19');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `languages`
--

CREATE TABLE `languages` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` char(49) CHARACTER SET utf8 DEFAULT NULL,
  `iso_639-1` char(2) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Tablo döküm verisi `languages`
--

INSERT INTO `languages` (`id`, `name`, `iso_639-1`) VALUES
(1, 'English', 'en'),
(2, 'Afar', 'aa'),
(3, 'Abkhazian', 'ab'),
(4, 'Afrikaans', 'af'),
(5, 'Amharic', 'am'),
(6, 'Arabic', 'ar'),
(7, 'Assamese', 'as'),
(8, 'Aymara', 'ay'),
(9, 'Azerbaijani', 'az'),
(11, 'Belarusian', 'be'),
(12, 'Bulgarian', 'bg'),
(13, 'Bihari', 'bh'),
(14, 'Bislama', 'bi'),
(15, 'Bengali/Bangla', 'bn'),
(17, 'Breton', 'br'),
(18, 'Catalan', 'ca'),
(19, 'Corsican', 'co'),
(20, 'Czech', 'cs'),
(21, 'Welsh', 'cy'),
(22, 'Danish', 'da'),
(23, 'German', 'de'),
(24, 'Bhutani', 'dz'),
(25, 'Greek', 'el'),
(26, 'Esperanto', 'eo'),
(27, 'Spanish', 'es'),
(28, 'Estonian', 'et'),
(29, 'Basque', 'eu'),
(30, 'Persian', 'fa'),
(31, 'Finnish', 'fi'),
(32, 'Fiji', 'fj'),
(33, 'Faeroese', 'fo'),
(34, 'French', 'fr'),
(35, 'Frisian', 'fy'),
(36, 'Irish', 'ga'),
(37, 'Scots/Gaelic', 'gd'),
(38, 'Galician', 'gl'),
(39, 'Guarani', 'gn'),
(40, 'Gujarati', 'gu'),
(41, 'Hausa', 'ha'),
(42, 'Hindi', 'hi'),
(43, 'Croatian', 'hr'),
(44, 'Hungarian', 'hu'),
(45, 'Armenian', 'hy'),
(46, 'Interlingua', 'ia'),
(47, 'Interlingue', 'ie'),
(48, 'Inupiak', 'ik'),
(49, 'Indonesian', 'in'),
(50, 'Icelandic', 'is'),
(51, 'Italian', 'it'),
(52, 'Hebrew', 'iw'),
(53, 'Japanese', 'ja'),
(54, 'Yiddish', 'ji'),
(55, 'Javanese', 'jw'),
(56, 'Georgian', 'ka'),
(57, 'Kazakh', 'kk'),
(58, 'Greenlandic', 'kl'),
(59, 'Cambodian', 'km'),
(60, 'Kannada', 'kn'),
(61, 'Korean', 'ko'),
(62, 'Kashmiri', 'ks'),
(63, 'Kurdish', 'ku'),
(64, 'Kirghiz', 'ky'),
(65, 'Latin', 'la'),
(66, 'Lingala', 'ln'),
(67, 'Laothian', 'lo'),
(68, 'Lithuanian', 'lt'),
(69, 'Latvian/Lettish', 'lv'),
(70, 'Malagasy', 'mg'),
(71, 'Maori', 'mi'),
(72, 'Macedonian', 'mk'),
(73, 'Malayalam', 'ml'),
(74, 'Mongolian', 'mn'),
(75, 'Moldavian', 'mo'),
(76, 'Marathi', 'mr'),
(77, 'Malay', 'ms'),
(78, 'Maltese', 'mt'),
(79, 'Burmese', 'my'),
(80, 'Nauru', 'na'),
(81, 'Nepali', 'ne'),
(82, 'Dutch', 'nl'),
(83, 'Norwegian', 'no'),
(84, 'Occitan', 'oc'),
(86, 'Punjabi', 'pa'),
(87, 'Polish', 'pl'),
(88, 'Pashto/Pushto', 'ps'),
(89, 'Portuguese', 'pt'),
(93, 'Romanian', 'ro'),
(94, 'Russian', 'ru'),
(101, 'Slovak', 'sk'),
(102, 'Slovenian', 'sl'),
(103, 'Samoan', 'sm'),
(105, 'Somali', 'so'),
(106, 'Albanian', 'sq'),
(107, 'Serbian', 'sr'),
(110, 'Sundanese', 'su'),
(111, 'Swedish', 'sv'),
(116, 'Thai', 'th'),
(117, 'Tigrinya', 'ti'),
(118, 'Turkmen', 'tk'),
(122, 'Turkish', 'tr'),
(123, 'Tsonga', 'ts'),
(124, 'Tatar', 'tt'),
(126, 'Ukrainian', 'uk'),
(127, 'Urdu', 'ur'),
(128, 'Uzbek', 'uz'),
(134, 'Chinese', 'zh');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `history`
--
ALTER TABLE `history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- Tablo için AUTO_INCREMENT değeri `languages`
--
ALTER TABLE `languages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=136;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
